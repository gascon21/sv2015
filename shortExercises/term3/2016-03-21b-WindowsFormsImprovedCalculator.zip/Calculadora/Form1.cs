﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        FrmOptions myOptions;
        public Form1()
        {
            InitializeComponent();
            myOptions = new FrmOptions();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                int n1 = Convert.ToInt32(tbFirstNumber.Text);
                int n2 = Convert.ToInt32(tbSecondNumber.Text);
                int result = 0;
                if (btCalculate.Text == "Add")
                    result = n1 + n2;
                else if (btCalculate.Text == "Multiply")
                    result = n1 * n2;
                else if (btCalculate.Text == "Divide")
                    result = n1 / n2;
                else if (btCalculate.Text == "Subtract")
                    result = n1 - n2;
                else if (btCalculate.Text == "Modulus")
                    result = n1 % n2;
                else
                    MessageBox.Show("Not a valid operation!","Error");


                tbTotal.Text = Convert.ToString(result);
            }
            catch (Exception)
            {
                MessageBox.Show("Error", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void btOperation_Click(object sender, EventArgs e)
        {
            myOptions.ShowDialog();
            string newText = myOptions.GetOperation();
            btCalculate.Text = newText;
        }
    }
}
