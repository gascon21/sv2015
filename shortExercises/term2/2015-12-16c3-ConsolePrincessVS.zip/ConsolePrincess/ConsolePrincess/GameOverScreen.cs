public class GameOverScreen : InfoScreen
{
}
