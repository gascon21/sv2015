public class Level
{
    protected Enemy myEnemy;
    protected Item  myItem;
}
