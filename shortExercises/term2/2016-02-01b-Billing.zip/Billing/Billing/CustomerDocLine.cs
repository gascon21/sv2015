﻿class CustomerDocLine
{
    protected int code;
    protected string description;
    protected double price;
    protected double amount;
    public CustomerDocLine(Item i, double amount)
    {
        this.code = i.GetCode();
        this.description = i.GetDescription();
        this.price = i.GetPrice();
        this.amount = amount;
    }
}

