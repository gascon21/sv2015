﻿// Nacho Cabanes
// sdl02.cs
// Segundo acercamiento a SDL

using Tao.Sdl;
using System; // Para IntPtr (puntero: imágenes, etc)

public class Sdl02
{

    public static void Main()
    {

        short anchoPantalla = 800;
        short altoPantalla = 600;

        Random r = new Random();
        const int ELEMENTS = 50;

        int[] x = new int[ELEMENTS];
        int[] y = new int[ELEMENTS];
        int[] incrX = new int[ELEMENTS];
        int[] incrY = new int[ELEMENTS];
        for (int i = 0; i < ELEMENTS; i++)
        {
            x[i] = r.Next(100, 700);
            y[i] = r.Next(50, 550);
            incrX[i] = r.Next(1, 5);
            incrY[i] = r.Next(1, 5);
        }

        int bitsColor = 24;
        int flags = Sdl.SDL_HWSURFACE | Sdl.SDL_DOUBLEBUF | Sdl.SDL_ANYFORMAT;
        //  | Sdl.SDL_FULLSCREEN;
        IntPtr pantallaOculta;

        // Inicializamos SDL
        Sdl.SDL_Init(Sdl.SDL_INIT_EVERYTHING);
        pantallaOculta = Sdl.SDL_SetVideoMode(
          anchoPantalla,
          altoPantalla,
          bitsColor,
          flags);

        // Indicamos que se recorte lo que salga de la pantalla oculta
        Sdl.SDL_Rect rect2 =
          new Sdl.SDL_Rect(0, 0, (short)anchoPantalla, (short)altoPantalla);
        Sdl.SDL_SetClipRect(pantallaOculta, ref rect2);

        // Cargamos una imagen
        IntPtr imagen;
        imagen = Sdl.SDL_LoadBMP("tie.bmp");
        if (imagen == IntPtr.Zero)
        {
            System.Console.WriteLine("Imagen inexistente!");
            Environment.Exit(1);
        }

        // Parte repetitiva
        bool terminado = false;
        short anchoImagen = 60;
        short altoImagen = 60;
        Sdl.SDL_Event suceso;
        int numkeys;
        byte[] teclas;

        do
        {
            // Comprobamos sucesos
            Sdl.SDL_PollEvent(out suceso);
            teclas = Sdl.SDL_GetKeyState(out numkeys);

            // ESC para salir
            if (teclas[Sdl.SDLK_ESCAPE] == 1)
                terminado = true;

            // Borramos pantalla
            Sdl.SDL_Rect origen = new Sdl.SDL_Rect(0, 0,
              anchoPantalla, altoPantalla);
            Sdl.SDL_FillRect(pantallaOculta, ref origen, 0);
            // Dibujamos en sus nuevas coordenadas
            origen = new Sdl.SDL_Rect(0, 0, anchoImagen, altoImagen);
            for (int i = 0; i < ELEMENTS; i++)
            {
                Sdl.SDL_Rect dest = new Sdl.SDL_Rect(
                    (short) x[i], (short) y[i],
                    anchoImagen, altoImagen);
                Sdl.SDL_BlitSurface(imagen, ref origen,
                    pantallaOculta, ref dest);
                x[i] += incrX[i];
                if ((x[i] < 0) || (x[i] > 750))
                    incrX[i] = -incrX[i];
                y[i] += incrY[i];
                if ((y[i] < 0) || (y[i] > 550))
                    incrY[i] = -incrY[i];
            }
            

            // Mostramos la pantalla oculta
            Sdl.SDL_Flip(pantallaOculta);

            // Y esperamos 20 ms
            System.Threading.Thread.Sleep(20);

        } while (!terminado);

        // Finalmente, cerramos SDL
        Sdl.SDL_Quit();
    }
}