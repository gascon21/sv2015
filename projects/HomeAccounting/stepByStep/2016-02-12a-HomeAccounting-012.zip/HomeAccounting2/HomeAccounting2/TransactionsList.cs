﻿/// <summary>
///  Home accounting: Class TransactionList (group of transactions)
///  @author Students at IES San Vicente, Spain
/// </summary>

/* --------------------------------------------------         
   Versions history
   
   Num.   Date        By / Changes
   ---------------------------------------------------
   0.12  12-Feb-2016  Nacho: Empty skeleton
 ---------------------------------------------------- */

namespace HomeAccounting2
{
    class TransactionsList
    {
    }
}
