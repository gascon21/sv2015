public class Game
{
    // Attributes
    protected Princess myPrincess;
    protected Level  myLevel;

    // Operations

    public  void DrawElements()
    {
        // TO DO
    }

    public  void CheckKeys()
    {
        // TO DO
    }

    public  void MoveElements()
    {
        // TO DO
    }

    public  void CheckCollisions()
    {
        // TO DO
    }

    public  void PauseTillNextFrame()
    {
        // TO DO
    }
} 
