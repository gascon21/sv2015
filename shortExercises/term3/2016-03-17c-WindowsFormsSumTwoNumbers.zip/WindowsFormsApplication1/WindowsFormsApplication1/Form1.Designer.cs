﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbFirstNumber = new System.Windows.Forms.Label();
            this.tbFirstNumber = new System.Windows.Forms.TextBox();
            this.lbSeondNumber = new System.Windows.Forms.Label();
            this.tbSecondNumber = new System.Windows.Forms.TextBox();
            this.tbSuma = new System.Windows.Forms.TextBox();
            this.lbSum = new System.Windows.Forms.Label();
            this.btCalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbFirstNumber
            // 
            this.lbFirstNumber.AutoSize = true;
            this.lbFirstNumber.Location = new System.Drawing.Point(48, 53);
            this.lbFirstNumber.Name = "lbFirstNumber";
            this.lbFirstNumber.Size = new System.Drawing.Size(87, 17);
            this.lbFirstNumber.TabIndex = 0;
            this.lbFirstNumber.Text = "First number";
            // 
            // tbFirstNumber
            // 
            this.tbFirstNumber.Location = new System.Drawing.Point(223, 53);
            this.tbFirstNumber.Name = "tbFirstNumber";
            this.tbFirstNumber.Size = new System.Drawing.Size(100, 22);
            this.tbFirstNumber.TabIndex = 1;
            this.tbFirstNumber.TextChanged += new System.EventHandler(this.tbFirstNumber_TextChanged);
            // 
            // lbSeondNumber
            // 
            this.lbSeondNumber.AutoSize = true;
            this.lbSeondNumber.Location = new System.Drawing.Point(48, 131);
            this.lbSeondNumber.Name = "lbSeondNumber";
            this.lbSeondNumber.Size = new System.Drawing.Size(110, 17);
            this.lbSeondNumber.TabIndex = 2;
            this.lbSeondNumber.Text = "Second Number";
            // 
            // tbSecondNumber
            // 
            this.tbSecondNumber.Location = new System.Drawing.Point(223, 126);
            this.tbSecondNumber.Name = "tbSecondNumber";
            this.tbSecondNumber.Size = new System.Drawing.Size(100, 22);
            this.tbSecondNumber.TabIndex = 3;
            // 
            // tbSuma
            // 
            this.tbSuma.Location = new System.Drawing.Point(223, 198);
            this.tbSuma.Name = "tbSuma";
            this.tbSuma.ReadOnly = true;
            this.tbSuma.Size = new System.Drawing.Size(100, 22);
            this.tbSuma.TabIndex = 4;
            // 
            // lbSum
            // 
            this.lbSum.AutoSize = true;
            this.lbSum.Location = new System.Drawing.Point(48, 201);
            this.lbSum.Name = "lbSum";
            this.lbSum.Size = new System.Drawing.Size(36, 17);
            this.lbSum.TabIndex = 5;
            this.lbSum.Text = "Sum";
            // 
            // btCalculate
            // 
            this.btCalculate.Location = new System.Drawing.Point(139, 269);
            this.btCalculate.Name = "btCalculate";
            this.btCalculate.Size = new System.Drawing.Size(75, 23);
            this.btCalculate.TabIndex = 6;
            this.btCalculate.Text = "SUM";
            this.btCalculate.UseVisualStyleBackColor = true;
            this.btCalculate.Click += new System.EventHandler(this.btCalculate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 330);
            this.Controls.Add(this.btCalculate);
            this.Controls.Add(this.lbSum);
            this.Controls.Add(this.tbSuma);
            this.Controls.Add(this.tbSecondNumber);
            this.Controls.Add(this.lbSeondNumber);
            this.Controls.Add(this.tbFirstNumber);
            this.Controls.Add(this.lbFirstNumber);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbFirstNumber;
        private System.Windows.Forms.TextBox tbFirstNumber;
        private System.Windows.Forms.Label lbSeondNumber;
        private System.Windows.Forms.TextBox tbSecondNumber;
        private System.Windows.Forms.TextBox tbSuma;
        private System.Windows.Forms.Label lbSum;
        private System.Windows.Forms.Button btCalculate;
    }
}

