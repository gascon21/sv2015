public class WelcomeScreen : InfoScreen
{
    public string GetSelectedOption()
    {
        // TO DO
        return "";
    }
}
