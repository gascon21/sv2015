﻿using System;

class Vehicle
{
    protected int wheels;
    protected double weight;
    protected string color;
    protected string brand;
    protected string model;
    protected short power;


    public void Accelerate()
    {
        Console.WriteLine("Accelerating");
    }


    public void Brake()
    {
        Console.WriteLine("Braking");
    }


    public void SetModel(string x)
    {
        model = x;
    }


    public string GetModel()
    {
        return model;
    }
}
