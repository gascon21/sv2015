﻿class PackingListLine : CustomerDocLine
{
    public PackingListLine(Item i, double amount)
        : base (i, amount)
    {
    }
}
