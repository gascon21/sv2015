﻿class Billing
{
    static void Main(string[] args)
    {
        // Test code
        Customer c1 = new Customer(
            1, "12345678A", "Ast Computers");

        Invoice invoice1 = new Invoice(c1);
        Item item1 = new Item(
            1, "386 SX Laptop", 2599.99);
        InvoiceLine line1 = new InvoiceLine(item1, 10);
        invoice1.Add(line1);
    }
}

