﻿class InvoiceLine : CustomerDocLine
{
    public InvoiceLine(Item i, double amount)
        : base (i, amount)
    {
    }
}
