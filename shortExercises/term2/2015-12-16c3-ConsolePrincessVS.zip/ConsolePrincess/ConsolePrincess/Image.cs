using System;

public class Image
{
    // Attributes
    public char symbol;
    public char symbol2;
    public ConsoleColor color;
}
