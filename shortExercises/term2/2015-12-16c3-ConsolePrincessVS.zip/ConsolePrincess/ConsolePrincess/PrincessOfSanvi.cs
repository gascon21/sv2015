public class PrincessOfSanvi
{
    public WelcomeScreen  myWelcomeScreen;
    public ConfigScreen  myConfigScreen;
    public CreditsScreen  myCreditsScreen;
    public GameOverScreen  myGameOverScreen;
    public Game  myGame;

    static void Main(string[] args)
    {
    }
}
