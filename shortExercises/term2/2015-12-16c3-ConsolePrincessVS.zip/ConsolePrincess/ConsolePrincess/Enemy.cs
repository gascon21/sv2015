public class Enemy : Sprite
{
}
