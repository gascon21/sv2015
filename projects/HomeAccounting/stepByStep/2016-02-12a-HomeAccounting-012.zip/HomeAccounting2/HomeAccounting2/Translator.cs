﻿/// <summary>
///  Home accounting: Class Translator (get texts translated to other languages)
///  @author Students at IES San Vicente, Spain
/// </summary>

/* --------------------------------------------------         
   Versions history
   
   Num.   Date        By / Changes
   ---------------------------------------------------
   0.12  12-Feb-2016  Nacho: Almost empty skeleton, returns the same sentence
 ---------------------------------------------------- */

namespace HomeAccounting2
{
    class Translator
    {
        public static string GetTranslation(string language, string sentence)
        {
            // TO DO: return real translation
            return sentence;
        }
    }
}
