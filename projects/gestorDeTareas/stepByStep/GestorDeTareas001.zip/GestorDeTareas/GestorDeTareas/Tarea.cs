﻿// Gestor de tareas
// Tarea: una tarea individial

// Version Por, cambios
// ---------------------------------------
//  0.01   Nacho, esqueleto vacío

class Tarea
{
}

