public class Sprite
{
    protected int x;
    protected int y;
    protected int horSpeed;
    protected int vertSpeed;

    protected Image  myImage;
    public  void Draw()
    {
        // TO DO
    }

    public  void Move()
    {
        // TO DO
    }
}
