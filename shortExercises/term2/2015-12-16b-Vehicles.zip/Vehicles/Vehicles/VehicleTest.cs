﻿using System;

public class VehicleTest
{
    public static void Main()
    {
        Car car = new Car();
        car.Accelerate();
        car.Brake();

        Truck truck = new Truck();
        truck.Load();

        Motorbike motorbike = new Motorbike();
        motorbike.SetModel("Monster");
        Console.WriteLine(motorbike.GetModel());
    }
}