﻿using System;

class Truck : Vehicle
{
    public void Load()
    {
        Console.WriteLine("Loading...");
    }
}