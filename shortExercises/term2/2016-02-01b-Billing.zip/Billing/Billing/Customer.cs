﻿class Customer
{
    protected int code;
    protected string id;
    protected string name;

    public Customer(int code, string id, string name)
    {
        this.code = code;
        this.id = id;
        this.name= name;
    }

    public int GetCode()
    {
        return code;
    }

    public string GetId()
    {
        return id;
    }

    public string GetName()
    {
        return name;
    }

    public void SetName(string newName)
    {
        name = newName;
    }
}
