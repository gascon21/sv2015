﻿using System;
class Invoice : CustomerDoc
{
    public Invoice(int number, DateTime date, Customer c)
        : base(number, date, c)
    {
    }

    public Invoice(DateTime date, Customer c) 
        : base(date, c)
    {
    }

    public Invoice(Customer c)
        : base(c)
    {
    }
}
