public class CreditsScreen : InfoScreen
{
}
