﻿using System;
class CustomerDoc
{
    protected int number;
    protected DateTime date;
    protected Customer customer;
    protected CustomerDocLine[] lines;
    protected int lastLine;


    public CustomerDoc(int number, DateTime date, Customer c)
    {
        this.number = number;
        this.date = date;
        customer = c;
        lines = new CustomerDocLine[100]; // to be improved later
        lastLine = 0;
    }

    public CustomerDoc(DateTime date, Customer c) 
        : this(0, date, c)
    {
        // TO DO: Get next number instead of passing 0
    }

    public CustomerDoc(Customer c)
        : this(DateTime.Now, c)
    {
        // TO DO: Get next number instead of passing 0
    }

    public void Add(CustomerDocLine c)
    {
        // Code example, not necessary
        lines[lastLine] = c;
        lastLine++;
    }
}

