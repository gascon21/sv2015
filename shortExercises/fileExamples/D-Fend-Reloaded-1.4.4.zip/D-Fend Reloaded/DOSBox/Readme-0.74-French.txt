13/05/2010
Ce fichier archive contient un pack de traduction en fran�ais des commandes et messages
ainsi que du fichier de configuration s'affichant sous dosbox 0.74.
Ce pack n'est pas compatible avec les versions pr�c�dentes de dosbox, consulter le site pour
t�l�charger la version appropri�e.

-------------

Proc�dure d'installation facile pour Windows :


1a. Pour Windows Vista et 7
Copier le fichier "francais074.lng" et "dosbox-074.conf" contenus dans l'archive vers le r�pertoire de dosbox 0.74 pour votre profil
"C:\Users\[votre nom]\AppData\Local\DOSBox" par d�faut
ATTENTION, faites une copie de sauvegarde du fichier "dosbox-074.conf" d�j� pr�sent par s�curit� (voir nota sinon).

1b. Pour Windows XP
Copier le fichier "francais074.lng" et "dosbox-074.conf" contenus dans l'archive vers le r�pertoire de dosbox 0.74 pour votre profil
"C:\Documents and Settings\[votre nom]\Local Settings\Application Data\DOSBox" par d�faut
ATTENTION, faites une copie de sauvegarde du fichier "dosbox-074.conf" d�j� pr�sent par s�curit� (voir nota sinon).

-------------

2. Le fichier de configuration est d�j� modifi� pour prendre en compte le fichier de traduction.
Ouvrir avec un �diteur de texte ou notepad le fichier "dosbox-074.conf" ou cliquer sur 
le raccourci "DOSBox 0.74 options" dans la section "Options" du groupe de programmes "DOSBox-0.74"


3. Lancer Dosbox. Il s'affiche maintenant en fran�ais!  :)

4. A l'invite de commande si le clavier n'est pas automatiquement configur� pour utiliser un clavier fran�ais, taper:
keyb fr

-------------

nota:
- Il est possible que la traduction ne concerne pas tous les messages d'information utilisables du programme.

- N'ont �t� traduits que les messages et les commandes disponibles en lan�ant sans fichier de langue
"CONFIG -writelang nom_de_fichier" sous DOSbox.

- R��crire le fichier de configuration modifi� � partir d'un fichier de langue en lan�ant (un fichier de langue �tant charg�, sinon le fichier sera en anglais)
"CONFIG -writeconf nom_de_fichier" sous DOSbox.
Le fichier cr�� se trouve dans le r�pertoire d'installation de DOSbox ("C:\Program Files\DOSBox-0.74" par d�faut).

- R�initialiser le fichier de configuration en cliquant sur le raccourci "Reset Options" dans la section "Options" du groupe de programmes "DOSBox-0.74"
Le fichier cr�� se trouve dans le r�pertoire d'installation de DOSbox ("C:\Program Files\DOSBox-0.74" par d�faut) et sera identique � celui par d�faut.

- Si vous trouvez des fautes de frappe ou d'orthographe, n'h�sitez pas les signaler � l'�quipe de d�veloppement qui transmettra ou bien directement
sur le forum http://www.abandonware-forums.org � mon intention.

-------------

Bons jeux !!!
Victor