﻿// Gestor de tareas
// Ventana de Tarea (Windows Forms)

/*
Version    Fecha    Por, cambios
---------------------------------------
 0.08   16-05-2016  Sacha Van de Sijpe, Carla Liarte, Cristian Navarrete
                      Primera versión de la ventana de Tarea
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public partial class VentanaTarea : Form
    {
        public VentanaTarea()
        {
            InitializeComponent();
        }
    }
}
