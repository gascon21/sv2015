﻿// Gestor de tareas
// ListaDeTareasRepetitivas: lista de varias tareas periódicas

// Version Por, cambios
// ---------------------------------------
//  0.01   Nacho, esqueleto vacío
class ListaDeTareasRepetitivas
{
}
