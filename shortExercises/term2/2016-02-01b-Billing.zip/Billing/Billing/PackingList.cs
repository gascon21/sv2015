﻿using System;
class PackingList : CustomerDoc
{
    public PackingList(int number, DateTime date, Customer c)
        : base(number, date, c)
    {
    }

    public PackingList(DateTime date, Customer c) 
        : base(date, c)
    {
    }

    public PackingList(Customer c)
        : base(c)
    {
    }
}
