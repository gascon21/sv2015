public class InfoScreen
{
    public  void Run()
    {
        // TO DO
    }
}
