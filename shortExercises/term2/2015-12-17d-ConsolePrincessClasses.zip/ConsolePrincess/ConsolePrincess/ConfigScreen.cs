public class ConfigScreen : InfoScreen
{
}
