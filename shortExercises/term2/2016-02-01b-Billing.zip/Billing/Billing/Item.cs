﻿class Item
{
    protected int code;
    protected string description;
    protected double price;

    public Item(int code, string description, double price)
    {
        this.code = code;
        this.description = description;
        this.price = price;
    }

    public int GetCode()
    {
        return code;
    }

    public string GetDescription()
    {
        return description;
    }

    public double GetPrice()
    {
        return price;
    }

    public void SetDescription(string newDescription)
    {
        description = newDescription;
    }

    public void SetPrice(double newPrice)
    {
        price = newPrice;
    }
}
