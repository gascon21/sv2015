﻿class Car : Vehicle 
{
    protected int doors;

    public Car()
    {
        wheels = 4;
    }
}
