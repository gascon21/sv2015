﻿// Gestor de tareas
// TareaRepetitiva: una tarea periódica individial

// Version Por, cambios
// ---------------------------------------
//  0.01   Nacho, esqueleto vacío

class TareaRepetitiva
{
}
