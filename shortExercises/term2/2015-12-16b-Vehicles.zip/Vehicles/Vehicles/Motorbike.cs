﻿class Motorbike : Vehicle
{
    public Motorbike()
    {
        wheels = 2;
    }
}