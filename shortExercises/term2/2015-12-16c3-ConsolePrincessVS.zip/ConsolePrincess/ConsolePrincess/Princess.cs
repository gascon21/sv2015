public class Princess : Sprite
{
}
