﻿/// <summary>
///  Home accounting: Class HelpScreen (help screen)
///  @author Students at IES San Vicente, Spain
/// </summary>

/* --------------------------------------------------         
   Versions history
   
   Num.   Date        By / Changes
   ---------------------------------------------------
   0.12  12-Feb-2016  Nacho: Almost empty skeleton
 ---------------------------------------------------- */

namespace HomeAccounting2
{
    class HelpScreen
    {
        public void Show()
        {
            // TO DO
        }
    }
}
