﻿// Gestor de tareas
// Programa principal (consola)

// Version Por, cambios
// ---------------------------------------
//  0.01   Nacho, esqueleto vacío
public class GestorDeTareas
{
    public static void Main(string[] args)
    {
    }
}
