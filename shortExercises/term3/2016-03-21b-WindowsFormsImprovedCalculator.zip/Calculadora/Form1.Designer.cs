﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbFirstNumber = new System.Windows.Forms.Label();
            this.tbFirstNumber = new System.Windows.Forms.TextBox();
            this.lbSecondNumber = new System.Windows.Forms.Label();
            this.tbSecondNumber = new System.Windows.Forms.TextBox();
            this.total = new System.Windows.Forms.Label();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.btCalculate = new System.Windows.Forms.Button();
            this.btOperation = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbFirstNumber
            // 
            this.lbFirstNumber.AutoSize = true;
            this.lbFirstNumber.Location = new System.Drawing.Point(22, 23);
            this.lbFirstNumber.Name = "lbFirstNumber";
            this.lbFirstNumber.Size = new System.Drawing.Size(70, 13);
            this.lbFirstNumber.TabIndex = 0;
            this.lbFirstNumber.Text = "First number: ";
            this.lbFirstNumber.Click += new System.EventHandler(this.label1_Click);
            // 
            // tbFirstNumber
            // 
            this.tbFirstNumber.Location = new System.Drawing.Point(191, 23);
            this.tbFirstNumber.Name = "tbFirstNumber";
            this.tbFirstNumber.Size = new System.Drawing.Size(100, 20);
            this.tbFirstNumber.TabIndex = 1;
            // 
            // lbSecondNumber
            // 
            this.lbSecondNumber.AutoSize = true;
            this.lbSecondNumber.Location = new System.Drawing.Point(22, 83);
            this.lbSecondNumber.Name = "lbSecondNumber";
            this.lbSecondNumber.Size = new System.Drawing.Size(88, 13);
            this.lbSecondNumber.TabIndex = 2;
            this.lbSecondNumber.Text = "Second number: ";
            // 
            // tbSecondNumber
            // 
            this.tbSecondNumber.Location = new System.Drawing.Point(191, 83);
            this.tbSecondNumber.Name = "tbSecondNumber";
            this.tbSecondNumber.Size = new System.Drawing.Size(100, 20);
            this.tbSecondNumber.TabIndex = 3;
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Location = new System.Drawing.Point(22, 175);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(37, 13);
            this.total.TabIndex = 4;
            this.total.Text = "Total: ";
            // 
            // tbTotal
            // 
            this.tbTotal.Location = new System.Drawing.Point(191, 175);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.ReadOnly = true;
            this.tbTotal.Size = new System.Drawing.Size(100, 20);
            this.tbTotal.TabIndex = 5;
            // 
            // btCalculate
            // 
            this.btCalculate.Location = new System.Drawing.Point(216, 232);
            this.btCalculate.Name = "btCalculate";
            this.btCalculate.Size = new System.Drawing.Size(75, 23);
            this.btCalculate.TabIndex = 6;
            this.btCalculate.Text = "Calculate";
            this.btCalculate.UseVisualStyleBackColor = true;
            this.btCalculate.Click += new System.EventHandler(this.btCalculate_Click);
            // 
            // btOperation
            // 
            this.btOperation.Location = new System.Drawing.Point(12, 232);
            this.btOperation.Name = "btOperation";
            this.btOperation.Size = new System.Drawing.Size(75, 23);
            this.btOperation.TabIndex = 7;
            this.btOperation.Text = "Operations";
            this.btOperation.UseVisualStyleBackColor = true;
            this.btOperation.Click += new System.EventHandler(this.btOperation_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 267);
            this.Controls.Add(this.btOperation);
            this.Controls.Add(this.btCalculate);
            this.Controls.Add(this.tbTotal);
            this.Controls.Add(this.total);
            this.Controls.Add(this.tbSecondNumber);
            this.Controls.Add(this.lbSecondNumber);
            this.Controls.Add(this.tbFirstNumber);
            this.Controls.Add(this.lbFirstNumber);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbFirstNumber;
        private System.Windows.Forms.TextBox tbFirstNumber;
        private System.Windows.Forms.Label lbSecondNumber;
        private System.Windows.Forms.TextBox tbSecondNumber;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.Button btCalculate;
        private System.Windows.Forms.Button btOperation;
    }
}

