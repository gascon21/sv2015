﻿// sdl01.cs
// Primer acercamiento a SDL
// Introducción a C#, por Nacho Cabanes

using Tao.Sdl;
using System; // Para IntPtr (puntero: imágenes, etc)

public class Sdl01
{

    public static void Main()
    {

        short anchoPantalla = 800;
        short altoPantalla = 600;
        int bitsColor = 8;
        int flags = Sdl.SDL_HWSURFACE | Sdl.SDL_DOUBLEBUF | Sdl.SDL_ANYFORMAT;
        IntPtr pantallaOculta;

        // Inicializamos SDL
        Sdl.SDL_Init(Sdl.SDL_INIT_EVERYTHING);
        pantallaOculta = Sdl.SDL_SetVideoMode(
          anchoPantalla,
          altoPantalla,
          bitsColor,
          flags);

        // Indicamos que se recorte lo que salga de la pantalla oculta
        Sdl.SDL_Rect rect2 =
          new Sdl.SDL_Rect(0, 0, (short)anchoPantalla, (short)altoPantalla);
        Sdl.SDL_SetClipRect(pantallaOculta, ref rect2);

        // Cargamos una imagen
        IntPtr imagen;
        imagen = Sdl.SDL_LoadBMP("personaje.bmp");
        if (imagen == IntPtr.Zero)
        {
            System.Console.WriteLine("Imagen inexistente!");
            Environment.Exit(1);
        }

        // Dibujamos la imagen
        short x = 400;
        short y = 300;
        short anchoImagen = 38;
        short altoImagen = 38;
        Sdl.SDL_Rect origen = new Sdl.SDL_Rect(0, 0, anchoImagen, altoImagen);
        Sdl.SDL_Rect dest = new Sdl.SDL_Rect(x, y, anchoImagen, altoImagen);
        Sdl.SDL_BlitSurface(imagen, ref origen, pantallaOculta, ref dest);

        // Mostramos la pantalla oculta
        Sdl.SDL_Flip(pantallaOculta);

        // Y esperamos 5 segundos
        System.Threading.Thread.Sleep(5000);

        // Finalmente, cerramos SDL
        Sdl.SDL_Quit();

    }

}
