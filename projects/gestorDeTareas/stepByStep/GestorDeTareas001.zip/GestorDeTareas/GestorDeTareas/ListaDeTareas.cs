﻿// Gestor de tareas
// ListaDeTareas: lista de varias tareas

// Version Por, cambios
// ---------------------------------------
//  0.01   Nacho, esqueleto vacío

class ListaDeTareas
{
}
